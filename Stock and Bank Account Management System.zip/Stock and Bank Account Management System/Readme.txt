Open up Visual Studio and from the menu, select File -> New -> Project...
2. Select Visual C++ and select WIN32
3. Select WIN32 Console Application from the Templates window
4. Enter a name for this new project, select where to save this project and press OK
5. In the Win32 Application Wizard, click Next
6. Select Empty project from the Additional Options and click Finish
7. Right-click Source Files from the Solution Explorer in the left and select Add -> New Item...
8. Select C++ File (.cpp) from the Templates window, enter a name for the file, and click Add
After writing your code, do the following to run the code:
1. Select Build -> Rebuild Solution
2. If there are syntax errors in your code (you can see these errors in the Output window below), fix them and Rebuild Solution again until all errors are fixed.
3. If this is successful, select Debug -> Start Without Debugging